import unit1Image from "@/assets/unit-1.jpg";
import unit2Image from "@/assets/unit-2.jpg";
import unit3Image from "@/assets/unit-3.jpg";

export interface Unit {
  id: string;
  title: string;
  city: string;
  cityId: string;
  price: number;
  image: string;
  type: string;
  capacity: number;
  available: boolean;
  description: string;
  features: string[];
  location: string;
  contact: string;
}

export const units: Unit[] = [
  {
    id: "1",
    title: "شقة مفروشة بالكامل - شرم الشيخ",
    city: "شرم الشيخ",
    cityId: "sharm",
    price: 2500,
    image: unit3Image,
    type: "ستوديو",
    capacity: 2,
    available: true,
    description: "شقة ستوديو مفروشة بالكامل في قلب شرم الشيخ، قريبة من الجامعة والمرافق الحيوية. تتميز بإطلالة رائعة على البحر الأحمر وتصميم عصري مريح.",
    features: [
      "مفروشة بالكامل",
      "إطلالة على البحر",
      "تكييف هواء",
      "إنترنت سريع",
      "أمن 24 ساعة",
      "موقف سيارات",
      "مطبخ مجهز",
      "حمام خاص"
    ],
    location: "حي النور، شرم الشيخ",
    contact: "+20 123 456 7890"
  },
  {
    id: "2",
    title: "غرفة مشتركة - رأس سدر",
    city: "رأس سدر",
    cityId: "ras-sadr",
    price: 800,
    image: unit1Image,
    type: "غرفة مشتركة",
    capacity: 1,
    available: true,
    description: "غرفة مريحة في شقة مشتركة نظيفة وآمنة، مثالية للطلاب الذين يبحثون عن سكن اقتصادي في رأس سدر. الشقة تضم مطبخ مشترك ومنطقة معيشة.",
    features: [
      "غرفة خاصة",
      "مطبخ مشترك",
      "صالة مشتركة",
      "إنترنت مجاني",
      "تكييف",
      "أمن",
      "غسالة ملابس",
      "منطقة دراسة"
    ],
    location: "وسط رأس سدر",
    contact: "+20 123 456 7891"
  },
  {
    id: "3",
    title: "شقة عائلية - الطور",
    city: "الطور",
    cityId: "el-tur",
    price: 1800,
    image: unit2Image,
    type: "شقة كاملة",
    capacity: 4,
    available: false,
    description: "شقة واسعة من غرفتين نوم وصالة، مناسبة للطلاب الذين يفضلون السكن الجماعي. تقع في منطقة هادئة قريبة من الجامعة والخدمات.",
    features: [
      "غرفتين نوم",
      "صالة واسعة",
      "مطبخ كامل",
      "حمامين",
      "بلكونة",
      "تكييف مركزي",
      "إنترنت",
      "موقف سيارات"
    ],
    location: "حي الجامعة، الطور",
    contact: "+20 123 456 7892"
  },
  {
    id: "4",
    title: "ستوديو حديث - شرم الشيخ",
    city: "شرم الشيخ",
    cityId: "sharm",
    price: 2200,
    image: unit1Image,
    type: "ستوديو",
    capacity: 2,
    available: true,
    description: "ستوديو عصري ومجهز بأحدث الأجهزة في منطقة نعمة بشرم الشيخ. مثالي للطلاب الذين يقدرون الراحة والخصوصية.",
    features: [
      "تصميم عصري",
      "أجهزة حديثة",
      "قريب من الشاطئ",
      "أمن وحراسة",
      "إنترنت فائق السرعة",
      "تكييف",
      "حمام سباحة",
      "جيم"
    ],
    location: "نعمة باي، شرم الشيخ",
    contact: "+20 123 456 7893"
  },
  {
    id: "5",
    title: "غرفة مفردة - رأس سدر",
    city: "رأس سدر",
    cityId: "ras-sadr",
    price: 1200,
    image: unit3Image,
    type: "غرفة مفردة",
    capacity: 1,
    available: true,
    description: "غرفة مفردة هادئة مع حمام خاص، مثالية للطلاب الذين يحتاجون التركيز في الدراسة. تقع في منطقة آمنة قريبة من الجامعة.",
    features: [
      "غرفة خاصة",
      "حمام خاص",
      "مكتب دراسة",
      "خزانة ملابس",
      "تكييف",
      "إنترنت",
      "مطبخ صغير",
      "منطقة هادئة"
    ],
    location: "حي الجامعة، رأس سدر",
    contact: "+20 123 456 7894"
  },
  {
    id: "6",
    title: "شقة مشتركة - الطور",
    city: "الطور",
    cityId: "el-tur",
    price: 1500,
    image: unit2Image,
    type: "شقة مشتركة",
    capacity: 3,
    available: true,
    description: "شقة من 3 غرف نوم للسكن المشترك، توفر بيئة اجتماعية مثالية للطلاب. تضم مرافق مشتركة عالية الجودة ومنطقة معيشة واسعة.",
    features: [
      "3 غرف نوم",
      "صالة مشتركة",
      "مطبخ مجهز",
      "2 حمام",
      "تراس",
      "إنترنت قوي",
      "تكييف",
      "أمن"
    ],
    location: "شارع الجامعة، الطور",
    contact: "+20 123 456 7895"
  }
];