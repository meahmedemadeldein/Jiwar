import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Users, 
  Star, 
  MessageSquare, 
  Shield, 
  BookOpen, 
  DollarSign,
  Clock,
  Heart,
  Share2,
  Flag
} from "lucide-react";
import { Unit } from "@/data/units";

interface StudentFeaturesProps {
  unit?: Unit;
  className?: string;
}

export const StudentFeatures = ({ unit, className }: StudentFeaturesProps) => {
  const [activeTab, setActiveTab] = useState("reviews");
  const [newReview, setNewReview] = useState({ rating: 5, comment: "" });
  const [roommateProfile, setRoommateProfile] = useState({
    studyField: "",
    studyYear: "",
    lifestyle: "",
    interests: ""
  });

  // Mock data for demonstration
  const reviews = [
    {
      id: 1,
      student: "أحمد محمد",
      rating: 5,
      comment: "مكان رائع ومريح للدراسة، المالك متعاون جداً والموقع ممتاز قريب من الجامعة",
      date: "2024-01-15",
      studyField: "هندسة",
      verified: true
    },
    {
      id: 2,
      student: "فاطمة أحمد",
      rating: 4,
      comment: "شقة نظيفة ومجهزة بشكل جيد، الإنترنت سريع والمرافق ممتازة",
      date: "2024-01-10",
      studyField: "طب",
      verified: true
    },
    {
      id: 3,
      student: "محمد علي",
      rating: 4,
      comment: "السعر مناسب والموقع جيد، لكن يحتاج تحسين في التهوية",
      date: "2024-01-05",
      studyField: "حاسوب",
      verified: false
    }
  ];

  const safetyFeatures = [
    { name: "أمن 24 ساعة", available: true },
    { name: "كاميرات مراقبة", available: true },
    { name: "إضاءة خارجية", available: true },
    { name: "مداخل آمنة", available: true },
    { name: "خدمة طوارئ", available: false },
    { name: "حراسة خاصة", available: false }
  ];

  const studyAmenities = [
    { name: "مكتب دراسة", available: true },
    { name: "إنترنت سريع", available: true },
    { name: "إضاءة جيدة", available: true },
    { name: "منطقة هادئة", available: true },
    { name: "مكتبة صغيرة", available: false },
    { name: "منطقة مذاكرة مشتركة", available: false }
  ];

  const financialOptions = [
    { name: "دفع شهري", available: true, description: "إمكانية الدفع شهرياً" },
    { name: "خصم للطلاب", available: true, description: "خصم 10% للطلاب المتفوقين" },
    { name: "تقسيط الدفعة الأولى", available: true, description: "إمكانية تقسيط دفعة التأمين" },
    { name: "خصم للإقامة الطويلة", available: false, description: "خصم للحجز أكثر من 6 أشهر" }
  ];

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  const handleReviewSubmit = () => {
    // Here you would normally submit to your backend
    console.log("New review:", newReview);
    setNewReview({ rating: 5, comment: "" });
  };

  return (
    <div className={className}>
      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 mb-6 border-b">
        {[
          { id: "reviews", label: "آراء الطلاب", icon: MessageSquare },
          { id: "safety", label: "الأمان", icon: Shield },
          { id: "study", label: "مرافق الدراسة", icon: BookOpen },
          { id: "financial", label: "خيارات الدفع", icon: DollarSign },
          { id: "roommate", label: "البحث عن زميل", icon: Users }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab(tab.id)}
              className="font-arabic"
            >
              <Icon className="h-4 w-4 ml-2" />
              {tab.label}
            </Button>
          );
        })}
      </div>

      {/* Reviews Tab */}
      {activeTab === "reviews" && (
        <div className="space-y-6">
          {/* Rating Summary */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="text-3xl font-bold">{averageRating.toFixed(1)}</div>
                <div>
                  <div className="flex gap-1">{renderStars(Math.round(averageRating))}</div>
                  <div className="text-sm text-muted-foreground font-arabic">
                    {reviews.length} تقييم من الطلاب
                  </div>
                </div>
              </div>
              
              {/* Rating Breakdown */}
              {[5, 4, 3, 2, 1].map(rating => {
                const count = reviews.filter(r => r.rating === rating).length;
                const percentage = (count / reviews.length) * 100;
                return (
                  <div key={rating} className="flex items-center gap-2 mb-2">
                    <span className="text-sm w-6">{rating}</span>
                    <Star className="h-4 w-4 text-yellow-400" />
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div 
                        className="bg-yellow-400 h-2 rounded-full" 
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground w-8">{count}</span>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Reviews List */}
          <div className="space-y-4">
            {reviews.map(review => (
              <Card key={review.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="font-semibold font-arabic">{review.student}</div>
                      {review.verified && (
                        <Badge variant="secondary" className="text-xs">
                          طالب موثق
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-xs font-arabic">
                        {review.studyField}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(review.date).toLocaleDateString('ar')}
                    </div>
                  </div>
                  
                  <div className="flex gap-1 mb-2">
                    {renderStars(review.rating)}
                  </div>
                  
                  <p className="text-sm font-arabic text-right leading-relaxed">
                    {review.comment}
                  </p>
                  
                  <div className="flex gap-2 mt-3">
                    <Button variant="ghost" size="sm">
                      <Heart className="h-4 w-4 ml-1" />
                      مفيد
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="h-4 w-4 ml-1" />
                      مشاركة
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Flag className="h-4 w-4 ml-1" />
                      إبلاغ
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Add Review */}
          <Card>
            <CardHeader>
              <CardTitle className="font-arabic text-right">إضافة تقييم</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="font-arabic">التقييم</Label>
                <div className="flex gap-1 mt-1">
                  {[1, 2, 3, 4, 5].map(rating => (
                    <Button
                      key={rating}
                      variant="ghost"
                      size="sm"
                      onClick={() => setNewReview(prev => ({ ...prev, rating }))}
                    >
                      <Star 
                        className={`h-5 w-5 ${rating <= newReview.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                      />
                    </Button>
                  ))}
                </div>
              </div>
              
              <div>
                <Label htmlFor="review-comment" className="font-arabic">تعليقك</Label>
                <Textarea
                  id="review-comment"
                  value={newReview.comment}
                  onChange={(e) => setNewReview(prev => ({ ...prev, comment: e.target.value }))}
                  placeholder="شاركنا تجربتك في هذه الوحدة..."
                  className="font-arabic text-right"
                />
              </div>
              
              <Button onClick={handleReviewSubmit} className="font-arabic">
                إرسال التقييم
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Safety Tab */}
      {activeTab === "safety" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">مرافق الأمان والحماية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {safetyFeatures.map(feature => (
                <div key={feature.name} className="flex items-center justify-between p-3 rounded-lg border">
                  <Badge variant={feature.available ? "default" : "secondary"}>
                    {feature.available ? "متوفر" : "غير متوفر"}
                  </Badge>
                  <span className="font-arabic">{feature.name}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold font-arabic mb-2 text-right">نصائح الأمان للطلاب</h4>
              <ul className="text-sm space-y-1 font-arabic text-right">
                <li>• احتفظ بأرقام الطوارئ في هاتفك</li>
                <li>• لا تشارك مفاتيحك مع الغرباء</li>
                <li>• أبلغ عن أي أنشطة مشبوهة فوراً</li>
                <li>• تأكد من إغلاق الأبواب والنوافذ</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Study Amenities Tab */}
      {activeTab === "study" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">مرافق الدراسة والتعلم</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {studyAmenities.map(amenity => (
                <div key={amenity.name} className="flex items-center justify-between p-3 rounded-lg border">
                  <Badge variant={amenity.available ? "default" : "secondary"}>
                    {amenity.available ? "متوفر" : "غير متوفر"}
                  </Badge>
                  <span className="font-arabic">{amenity.name}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold font-arabic mb-2 text-right">بيئة مثالية للدراسة</h4>
              <p className="text-sm font-arabic text-right">
                هذه الوحدة مصممة خصيصاً لتوفير بيئة مثالية للطلاب، مع مراعاة احتياجات الدراسة والتركيز.
                الإنترنت السريع والإضاءة المناسبة ومساحة العمل المريحة تضمن لك تجربة دراسة متميزة.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Financial Options Tab */}
      {activeTab === "financial" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">خيارات الدفع المرنة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {financialOptions.map(option => (
                <div key={option.name} className="flex items-center justify-between p-4 rounded-lg border">
                  <div className="text-right">
                    <div className="flex items-center gap-2">
                      <Badge variant={option.available ? "default" : "secondary"}>
                        {option.available ? "متاح" : "غير متاح"}
                      </Badge>
                      <span className="font-semibold font-arabic">{option.name}</span>
                    </div>
                    <p className="text-sm text-muted-foreground font-arabic mt-1">
                      {option.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-yellow-50 rounded-lg">
              <h4 className="font-semibold font-arabic mb-2 text-right">معلومات مالية مهمة</h4>
              <ul className="text-sm space-y-1 font-arabic text-right">
                <li>• يمكن دفع الإيجار في بداية كل شهر</li>
                <li>• مطلوب دفعة تأمين مقدمة (قابلة للاسترداد)</li>
                <li>• المرافق والخدمات مشمولة في السعر</li>
                <li>• خصومات خاصة للطلاب المتفوقين</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Roommate Finder Tab */}
      {activeTab === "roommate" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">البحث عن زميل سكن</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="study-field" className="font-arabic">مجال الدراسة</Label>
                <Input
                  id="study-field"
                  value={roommateProfile.studyField}
                  onChange={(e) => setRoommateProfile(prev => ({ ...prev, studyField: e.target.value }))}
                  placeholder="مثل: هندسة، طب، حاسوب"
                  className="font-arabic text-right"
                />
              </div>
              
              <div>
                <Label htmlFor="study-year" className="font-arabic">السنة الدراسية</Label>
                <Input
                  id="study-year"
                  value={roommateProfile.studyYear}
                  onChange={(e) => setRoommateProfile(prev => ({ ...prev, studyYear: e.target.value }))}
                  placeholder="مثل: السنة الثانية"
                  className="font-arabic text-right"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="lifestyle" className="font-arabic">نمط الحياة</Label>
              <Input
                id="lifestyle"
                value={roommateProfile.lifestyle}
                onChange={(e) => setRoommateProfile(prev => ({ ...prev, lifestyle: e.target.value }))}
                placeholder="مثل: هادئ، اجتماعي، مدخن/غير مدخن"
                className="font-arabic text-right"
              />
            </div>
            
            <div>
              <Label htmlFor="interests" className="font-arabic">الاهتمامات</Label>
              <Textarea
                id="interests"
                value={roommateProfile.interests}
                onChange={(e) => setRoommateProfile(prev => ({ ...prev, interests: e.target.value }))}
                placeholder="اكتب عن اهتماماتك وهواياتك..."
                className="font-arabic text-right"
              />
            </div>
            
            <Button className="w-full font-arabic">
              <Users className="h-4 w-4 ml-2" />
              البحث عن زملاء مناسبين
            </Button>
            
            <div className="mt-6 p-4 bg-purple-50 rounded-lg">
              <h4 className="font-semibold font-arabic mb-2 text-right">نصائح لاختيار زميل السكن</h4>
              <ul className="text-sm space-y-1 font-arabic text-right">
                <li>• تحدث معه أولاً عبر الهاتف أو الفيديو</li>
                <li>• اتفقوا على قواعد واضحة للسكن المشترك</li>
                <li>• تأكد من التوافق في أوقات النوم والدراسة</li>
                <li>• ناقش تقسيم المصروفات والأعمال المنزلية</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};