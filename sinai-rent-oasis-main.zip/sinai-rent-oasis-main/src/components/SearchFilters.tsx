import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Search, Filter, X, MapPin, DollarSign, Users, Home, BookmarkPlus } from "lucide-react";
import { Unit } from "@/data/units";

interface SearchFiltersProps {
  units: Unit[];
  onFilteredUnits: (units: Unit[]) => void;
  onSaveSearch?: (filters: any) => void;
}

export const SearchFilters = ({ units, onFilteredUnits, onSaveSearch }: SearchFiltersProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [priceRange, setPriceRange] = useState([500, 3000]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [capacityRange, setCapacityRange] = useState([1, 4]);
  const [sortBy, setSortBy] = useState("price-low");
  const [onlyAvailable, setOnlyAvailable] = useState(true);

  const unitTypes = [...new Set(units.map(unit => unit.type))];
  const allFeatures = [...new Set(units.flatMap(unit => unit.features))];

  const applyFilters = () => {
    let filtered = units.filter(unit => {
      const matchesSearch = searchTerm === "" || 
        unit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        unit.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        unit.city.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesPrice = unit.price >= priceRange[0] && unit.price <= priceRange[1];
      const matchesType = selectedTypes.length === 0 || selectedTypes.includes(unit.type);
      const matchesCapacity = unit.capacity >= capacityRange[0] && unit.capacity <= capacityRange[1];
      const matchesAvailability = !onlyAvailable || unit.available;
      const matchesFeatures = selectedFeatures.length === 0 || 
        selectedFeatures.every(feature => unit.features.includes(feature));

      return matchesSearch && matchesPrice && matchesType && matchesCapacity && matchesAvailability && matchesFeatures;
    });

    // Apply sorting
    switch (sortBy) {
      case "price-low":
        filtered.sort((a, b) => a.price - b.price);
        break;
      case "price-high":
        filtered.sort((a, b) => b.price - a.price);
        break;
      case "capacity-low":
        filtered.sort((a, b) => a.capacity - b.capacity);
        break;
      case "capacity-high":
        filtered.sort((a, b) => b.capacity - a.capacity);
        break;
      case "availability":
        filtered.sort((a, b) => (b.available ? 1 : 0) - (a.available ? 1 : 0));
        break;
    }

    onFilteredUnits(filtered);
  };

  const handleTypeToggle = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const handleFeatureToggle = (feature: string) => {
    setSelectedFeatures(prev => 
      prev.includes(feature) 
        ? prev.filter(f => f !== feature)
        : [...prev, feature]
    );
  };

  const clearFilters = () => {
    setSearchTerm("");
    setPriceRange([500, 3000]);
    setSelectedTypes([]);
    setSelectedFeatures([]);
    setCapacityRange([1, 4]);
    setSortBy("price-low");
    setOnlyAvailable(true);
    onFilteredUnits(units);
  };

  const saveCurrentSearch = () => {
    const filters = {
      searchTerm,
      priceRange,
      selectedTypes,
      selectedFeatures,
      capacityRange,
      sortBy,
      onlyAvailable,
      savedAt: new Date().toISOString()
    };
    onSaveSearch?.(filters);
  };

  // Apply filters whenever any filter changes
  useEffect(() => {
    applyFilters();
  }, [searchTerm, priceRange, selectedTypes, selectedFeatures, capacityRange, sortBy, onlyAvailable]);

  return (
    <div className="mb-6">
      {/* Search Bar and Quick Actions */}
      <div className="flex gap-4 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="ابحث عن وحدة سكنية، موقع، أو مرافق..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10 font-arabic text-right"
          />
        </div>
        <Button
          variant="outline"
          onClick={() => setIsOpen(!isOpen)}
          className="font-arabic"
        >
          <Filter className="h-4 w-4 ml-2" />
          فلاتر متقدمة
          {(selectedTypes.length > 0 || selectedFeatures.length > 0) && (
            <Badge variant="secondary" className="mr-2">
              {selectedTypes.length + selectedFeatures.length}
            </Badge>
          )}
        </Button>
        <Button
          variant="ghost"
          onClick={saveCurrentSearch}
          className="font-arabic"
          title="حفظ البحث الحالي"
        >
          <BookmarkPlus className="h-4 w-4" />
        </Button>
      </div>

      {/* Advanced Filters Panel */}
      {isOpen && (
        <Card className="mb-6">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="font-arabic text-right">الفلاتر المتقدمة</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={clearFilters} className="font-arabic">
                  <X className="h-4 w-4 ml-2" />
                  مسح الكل
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Price Range */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <label className="text-sm font-medium font-arabic">نطاق السعر (جنيه شهرياً)</label>
              </div>
              <div className="px-3">
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={5000}
                  min={500}
                  step={100}
                  className="mb-2"
                />
                <div className="flex justify-between text-sm text-muted-foreground font-arabic">
                  <span>{priceRange[1]} جنيه</span>
                  <span>{priceRange[0]} جنيه</span>
                </div>
              </div>
            </div>

            {/* Capacity Range */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-4 w-4 text-muted-foreground" />
                <label className="text-sm font-medium font-arabic">عدد الطلاب</label>
              </div>
              <div className="px-3">
                <Slider
                  value={capacityRange}
                  onValueChange={setCapacityRange}
                  max={8}
                  min={1}
                  step={1}
                  className="mb-2"
                />
                <div className="flex justify-between text-sm text-muted-foreground font-arabic">
                  <span>{capacityRange[1]} طلاب</span>
                  <span>{capacityRange[0]} طالب</span>
                </div>
              </div>
            </div>

            {/* Unit Types */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Home className="h-4 w-4 text-muted-foreground" />
                <label className="text-sm font-medium font-arabic">نوع الوحدة</label>
              </div>
              <div className="flex flex-wrap gap-2">
                {unitTypes.map(type => (
                  <Button
                    key={type}
                    variant={selectedTypes.includes(type) ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleTypeToggle(type)}
                    className="font-arabic"
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>

            {/* Key Features */}
            <div>
              <label className="text-sm font-medium font-arabic mb-3 block">المرافق المطلوبة</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {allFeatures.slice(0, 12).map(feature => (
                  <div key={feature} className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox
                      id={feature}
                      checked={selectedFeatures.includes(feature)}
                      onCheckedChange={(checked) => {
                        if (checked !== "indeterminate") {
                          handleFeatureToggle(feature);
                        }
                      }}
                    />
                    <label htmlFor={feature} className="text-sm font-arabic">
                      {feature}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Sort and Availability */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium font-arabic mb-2 block">ترتيب النتائج</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="font-arabic">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-low" className="font-arabic">السعر: من الأقل للأعلى</SelectItem>
                    <SelectItem value="price-high" className="font-arabic">السعر: من الأعلى للأقل</SelectItem>
                    <SelectItem value="capacity-low" className="font-arabic">السعة: من الأقل للأعلى</SelectItem>
                    <SelectItem value="capacity-high" className="font-arabic">السعة: من الأعلى للأقل</SelectItem>
                    <SelectItem value="availability" className="font-arabic">المتاح أولاً</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id="available-only"
                    checked={onlyAvailable}
                    onCheckedChange={(checked) => {
                      if (checked !== "indeterminate") {
                        setOnlyAvailable(checked);
                      }
                    }}
                  />
                  <label htmlFor="available-only" className="text-sm font-arabic">
                    الوحدات المتاحة فقط
                  </label>
                </div>
              </div>
            </div>

          </CardContent>
        </Card>
      )}
    </div>
  );
};