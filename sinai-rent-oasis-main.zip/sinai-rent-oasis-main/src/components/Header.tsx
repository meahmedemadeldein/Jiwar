import { Button } from "@/components/ui/button";
import { Search, MapPin, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

export const Header = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <header className="bg-white shadow-elegant border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center">
              <MapPin className="h-6 w-6 text-white" />
            </div>
            <div className="text-right">
              <Link to="/">
                <h1 className="text-xl font-bold text-sinai-blue font-arabic">سيناء للإيجار</h1>
                <p className="text-xs text-muted-foreground font-arabic">وحدات سكنية للطلاب</p>
              </Link>
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex items-center gap-2 bg-muted rounded-full px-4 py-2 flex-1 max-w-md mx-8">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="ابحث عن وحدة سكنية..." 
              className="bg-transparent border-none outline-none text-sm font-arabic flex-1 text-right"
            />
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-4">
            <Link 
              to="/" 
              className={`font-arabic ${isActive('/') ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'}`}
            >
              الرئيسية
            </Link>
            <Link 
              to="/services" 
              className={`font-arabic ${isActive('/services') ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'}`}
            >
              خدماتنا
            </Link>
            <Button variant="outline" size="sm" className="font-arabic">
              <User className="h-4 w-4 ml-2" />
              تسجيل الدخول
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-4">
          <div className="flex items-center gap-2 bg-muted rounded-lg px-4 py-3">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="ابحث عن وحدة سكنية..." 
              className="bg-transparent border-none outline-none text-sm font-arabic flex-1 text-right"
            />
          </div>
        </div>
      </div>
    </header>
  );
};