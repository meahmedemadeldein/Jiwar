import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { Wrench, Zap, Droplets, Hammer, PaintBucket, Home } from "lucide-react";

interface ServiceRequestData {
  name: string;
  phone: string;
  email: string;
  address: string;
  serviceType: string;
  urgency: string;
  description: string;
  preferredTime: string;
}

const serviceTypes = [
  { value: "plumber", label: "سباك", icon: Droplets },
  { value: "electrician", label: "كهربائي", icon: Zap },
  { value: "carpenter", label: "نجار", icon: Hammer },
  { value: "painter", label: "دهان", icon: PaintBucket },
  { value: "maintenance", label: "صيانة عامة", icon: Wrench },
  { value: "cleaning", label: "تنظيف", icon: Home },
];

export const ServiceRequestForm = () => {
  const { toast } = useToast();
  const form = useForm<ServiceRequestData>();

  const onSubmit = (data: ServiceRequestData) => {
    // Save to localStorage for now
    const serviceRequests = JSON.parse(localStorage.getItem('service-requests') || '[]');
    serviceRequests.push({
      id: Date.now(),
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('service-requests', JSON.stringify(serviceRequests));
    
    toast({
      title: "تم إرسال طلب الخدمة",
      description: "سنتواصل معك قريباً لتحديد موعد الخدمة",
    });
    
    form.reset();
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="font-arabic text-right flex items-center gap-2 justify-end">
          <Wrench className="h-5 w-5" />
          طلب خدمة صيانة
        </CardTitle>
        <CardDescription className="font-arabic text-right">
          احصل على خدمات الصيانة والإصلاح من خبراء معتمدين
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Service Type Selection */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
          {serviceTypes.map((service) => {
            const IconComponent = service.icon;
            return (
              <Button
                key={service.value}
                variant="outline"
                className="h-auto p-4 flex flex-col items-center gap-2 font-arabic"
                onClick={() => form.setValue('serviceType', service.value)}
              >
                <IconComponent className="h-6 w-6" />
                <span className="text-sm">{service.label}</span>
              </Button>
            );
          })}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                rules={{ required: "الاسم مطلوب" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-arabic">الاسم الكامل</FormLabel>
                    <FormControl>
                      <Input {...field} className="text-right font-arabic" placeholder="أدخل اسمك الكامل" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="phone"
                rules={{ required: "رقم الهاتف مطلوب" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-arabic">رقم الهاتف</FormLabel>
                    <FormControl>
                      <Input {...field} className="text-right font-arabic" placeholder="05xxxxxxxx" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="email"
              rules={{ required: "البريد الإلكتروني مطلوب" }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-arabic">البريد الإلكتروني</FormLabel>
                  <FormControl>
                    <Input {...field} type="email" className="text-right font-arabic" placeholder="example@email.com" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              rules={{ required: "العنوان مطلوب" }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-arabic">عنوان الخدمة</FormLabel>
                  <FormControl>
                    <Input {...field} className="text-right font-arabic" placeholder="أدخل العنوان بالتفصيل" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="serviceType"
                rules={{ required: "نوع الخدمة مطلوب" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-arabic">نوع الخدمة</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="font-arabic">
                          <SelectValue placeholder="اختر نوع الخدمة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {serviceTypes.map((service) => (
                          <SelectItem key={service.value} value={service.value}>
                            {service.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="urgency"
                rules={{ required: "الأولوية مطلوبة" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-arabic">درجة الأولوية</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="font-arabic">
                          <SelectValue placeholder="اختر الأولوية" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">عادية</SelectItem>
                        <SelectItem value="medium">متوسطة</SelectItem>
                        <SelectItem value="high">عاجلة</SelectItem>
                        <SelectItem value="emergency">طارئة</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="preferredTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-arabic">الوقت المفضل</FormLabel>
                  <FormControl>
                    <Input {...field} className="text-right font-arabic" placeholder="مثال: صباحاً من 9-12، مساءً من 5-8" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              rules={{ required: "وصف المشكلة مطلوب" }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-arabic">وصف المشكلة</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      className="text-right font-arabic" 
                      placeholder="اشرح المشكلة بالتفصيل..."
                      rows={4}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full font-arabic">
              إرسال طلب الخدمة
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};