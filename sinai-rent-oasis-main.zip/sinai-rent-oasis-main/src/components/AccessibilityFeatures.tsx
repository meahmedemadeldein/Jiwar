import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Eye, 
  EyeOff, 
  Volume2, 
  VolumeX, 
  Type, 
  Palette, 
  MousePointer, 
  Keyboard,
  Languages,
  HelpCircle,
  Settings
} from "lucide-react";

interface AccessibilityFeaturesProps {
  className?: string;
}

export const AccessibilityFeatures = ({ className }: AccessibilityFeaturesProps) => {
  const [isVisible, setIsVisible] = useState(false);
  const [fontSize, setFontSize] = useState(16);
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [screenReader, setScreenReader] = useState(false);
  const [keyboardNav, setKeyboardNav] = useState(false);

  // Check for user preferences on mount
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const prefersHighContrast = window.matchMedia('(prefers-contrast: high)').matches;
    
    setReducedMotion(prefersReducedMotion);
    setHighContrast(prefersHighContrast);
    
    // Apply stored preferences
    const storedFontSize = localStorage.getItem('accessibility-font-size');
    if (storedFontSize) {
      setFontSize(parseInt(storedFontSize));
      document.documentElement.style.fontSize = `${storedFontSize}px`;
    }
  }, []);

  // Apply accessibility changes
  useEffect(() => {
    const root = document.documentElement;
    
    if (highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
    
    if (reducedMotion) {
      root.classList.add('reduced-motion');
    } else {
      root.classList.remove('reduced-motion');
    }
    
    if (keyboardNav) {
      root.classList.add('keyboard-nav');
    } else {
      root.classList.remove('keyboard-nav');
    }
  }, [highContrast, reducedMotion, keyboardNav]);

  const changeFontSize = (delta: number) => {
    const newSize = Math.max(12, Math.min(24, fontSize + delta));
    setFontSize(newSize);
    document.documentElement.style.fontSize = `${newSize}px`;
    localStorage.setItem('accessibility-font-size', newSize.toString());
  };

  const toggleHighContrast = () => {
    setHighContrast(!highContrast);
    localStorage.setItem('accessibility-high-contrast', (!highContrast).toString());
  };

  const toggleReducedMotion = () => {
    setReducedMotion(!reducedMotion);
    localStorage.setItem('accessibility-reduced-motion', (!reducedMotion).toString());
  };

  const announceToScreenReader = (message: string) => {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;
    document.body.appendChild(announcement);
    setTimeout(() => document.body.removeChild(announcement), 1000);
  };

  const handleKeyboardToggle = () => {
    setKeyboardNav(!keyboardNav);
    announceToScreenReader(keyboardNav ? 'تم إيقاف التنقل بالكيبورد' : 'تم تفعيل التنقل بالكيبورد');
  };

  if (!isVisible) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsVisible(true)}
        className={`fixed bottom-4 left-4 z-50 font-arabic ${className}`}
        aria-label="فتح أدوات إمكانية الوصول"
      >
        <Eye className="h-4 w-4 ml-2" />
        إمكانية الوصول
      </Button>
    );
  }

  return (
    <Card className={`fixed bottom-4 left-4 z-50 w-80 ${className}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold font-arabic text-right">أدوات إمكانية الوصول</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsVisible(false)}
            aria-label="إغلاق أدوات إمكانية الوصول"
          >
            <EyeOff className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-3">
          
          {/* Font Size Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => changeFontSize(-2)}
                aria-label="تصغير حجم الخط"
              >
                أ-
              </Button>
              <span className="text-sm font-arabic">{fontSize}px</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => changeFontSize(2)}
                aria-label="تكبير حجم الخط"
              >
                أ+
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Type className="h-4 w-4" />
              <span className="text-sm font-arabic">حجم الخط</span>
            </div>
          </div>

          {/* High Contrast */}
          <div className="flex items-center justify-between">
            <Button
              variant={highContrast ? "default" : "outline"}
              size="sm"
              onClick={toggleHighContrast}
              aria-label={`${highContrast ? 'إيقاف' : 'تفعيل'} التباين العالي`}
            >
              {highContrast ? 'مفعل' : 'معطل'}
            </Button>
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              <span className="text-sm font-arabic">التباين العالي</span>
            </div>
          </div>

          {/* Reduced Motion */}
          <div className="flex items-center justify-between">
            <Button
              variant={reducedMotion ? "default" : "outline"}
              size="sm"
              onClick={toggleReducedMotion}
              aria-label={`${reducedMotion ? 'إيقاف' : 'تفعيل'} تقليل الحركة`}
            >
              {reducedMotion ? 'مفعل' : 'معطل'}
            </Button>
            <div className="flex items-center gap-2">
              <MousePointer className="h-4 w-4" />
              <span className="text-sm font-arabic">تقليل الحركة</span>
            </div>
          </div>

          {/* Keyboard Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant={keyboardNav ? "default" : "outline"}
              size="sm"
              onClick={handleKeyboardToggle}
              aria-label={`${keyboardNav ? 'إيقاف' : 'تفعيل'} التنقل بالكيبورد`}
            >
              {keyboardNav ? 'مفعل' : 'معطل'}
            </Button>
            <div className="flex items-center gap-2">
              <Keyboard className="h-4 w-4" />
              <span className="text-sm font-arabic">التنقل بالكيبورد</span>
            </div>
          </div>

          {/* Screen Reader Support */}
          <div className="border-t pt-3">
            <div className="text-xs text-muted-foreground font-arabic text-right mb-2">
              معلومات مفيدة:
            </div>
            <div className="space-y-1 text-xs font-arabic">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Tab</Badge>
                <span>للتنقل بين العناصر</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Enter</Badge>
                <span>لتنفيذ الإجراء</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Esc</Badge>
                <span>للإغلاق أو العودة</span>
              </div>
            </div>
          </div>

          {/* Help Button */}
          <Button
            variant="outline"
            size="sm"
            className="w-full font-arabic"
            onClick={() => announceToScreenReader('مرحباً بك في أدوات إمكانية الوصول. يمكنك استخدام هذه الأدوات لتحسين تجربة التصفح.')}
          >
            <HelpCircle className="h-4 w-4 ml-2" />
            مساعدة
          </Button>

        </div>
      </CardContent>
    </Card>
  );
};