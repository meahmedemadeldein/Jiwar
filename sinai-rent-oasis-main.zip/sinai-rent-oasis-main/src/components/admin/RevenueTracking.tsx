import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DollarSign, TrendingUp, TrendingDown, CreditCard, Wallet, Building } from "lucide-react";
import { useState } from "react";

const RevenueTracking = () => {
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  const revenueStats = [
    {
      title: "إجمالي الإيرادات",
      value: "342,500",
      change: "+15.3%",
      trend: "up",
      icon: DollarSign,
      period: "هذا الشهر"
    },
    {
      title: "الإيرادات المتوقعة",
      value: "289,300",
      change: "+8.7%",
      trend: "up",
      icon: TrendingUp,
      period: "الشهر القادم"
    },
    {
      title: "العمولات",
      value: "25,680",
      change: "+12.1%",
      trend: "up",
      icon: CreditCard,
      period: "هذا الشهر"
    },
    {
      title: "الأرباح الصافية",
      value: "316,820",
      change: "+16.9%",
      trend: "up",
      icon: Wallet,
      period: "هذا الشهر"
    }
  ];

  const cityRevenues = [
    { city: "القاهرة", revenue: "125,000", bookings: 45, avgPrice: "2,780", percentage: 85 },
    { city: "الإسكندرية", revenue: "89,500", bookings: 32, avgPrice: "2,797", percentage: 70 },
    { city: "الغردقة", revenue: "76,200", bookings: 28, avgPrice: "2,721", percentage: 60 },
    { city: "شرم الشيخ", revenue: "51,800", bookings: 15, avgPrice: "3,453", percentage: 45 },
  ];

  const recentTransactions = [
    {
      id: 1,
      user: "أحمد محمد",
      unit: "شقة في المعادي",
      amount: "2,500",
      commission: "250",
      date: "2024-01-20",
      status: "completed",
      method: "visa"
    },
    {
      id: 2,
      user: "فاطمة حسن",
      unit: "استوديو في الزمالك",
      amount: "3,200",
      commission: "320",
      date: "2024-01-19",
      status: "pending",
      method: "mastercard"
    },
    {
      id: 3,
      user: "محمد علي",
      unit: "شقة في المهندسين",
      amount: "2,800",
      commission: "280",
      date: "2024-01-18",
      status: "completed",
      method: "cash"
    },
    {
      id: 4,
      user: "سارة أحمد",
      unit: "فيلا في التجمع الخامس",
      amount: "4,500",
      commission: "450",
      date: "2024-01-17",
      status: "refunded",
      method: "visa"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">مكتمل</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">قيد المعالجة</Badge>;
      case "refunded":
        return <Badge variant="destructive">مسترد</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "visa":
        return "💳";
      case "mastercard":
        return "💳";
      case "cash":
        return "💵";
      default:
        return "💰";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold font-arabic">تتبع الإيرادات</h2>
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">هذا الأسبوع</SelectItem>
            <SelectItem value="month">هذا الشهر</SelectItem>
            <SelectItem value="quarter">هذا الربع</SelectItem>
            <SelectItem value="year">هذا العام</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {revenueStats.map((stat) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown;
          
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium font-arabic">
                  {stat.title}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value} ج.م</div>
                <div className={`flex items-center text-xs ${
                  stat.trend === "up" ? "text-green-600" : "text-red-600"
                }`}>
                  <TrendIcon className="h-3 w-3 mr-1" />
                  {stat.change}
                </div>
                <p className="text-xs text-muted-foreground font-arabic mt-1">
                  {stat.period}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic">الإيرادات حسب المدينة</CardTitle>
            <CardDescription className="font-arabic">
              توزيع الإيرادات والمتوسطات لكل مدينة
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {cityRevenues.map((city) => (
              <div key={city.city} className="space-y-2">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="font-medium font-arabic">{city.city}</span>
                    <div className="text-sm text-muted-foreground">
                      {city.bookings} حجز • متوسط {city.avgPrice} ج.م
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{city.revenue} ج.م</div>
                  </div>
                </div>
                <Progress value={city.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-arabic">الأداء المالي</CardTitle>
            <CardDescription className="font-arabic">
              مؤشرات الأداء المالي الرئيسية
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل النمو الشهري</span>
                <span className="font-bold text-green-600">+15.3%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">متوسط قيمة الحجز</span>
                <span className="font-bold">2,890 ج.م</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل العمولة</span>
                <span className="font-bold">7.5%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">إجمالي المعاملات</span>
                <span className="font-bold">342</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-arabic">المعاملات الأخيرة</CardTitle>
          <CardDescription className="font-arabic">
            آخر المعاملات المالية في النظام
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right font-arabic">المستخدم</TableHead>
                <TableHead className="text-right font-arabic">الوحدة</TableHead>
                <TableHead className="text-right font-arabic">المبلغ</TableHead>
                <TableHead className="text-right font-arabic">العمولة</TableHead>
                <TableHead className="text-right font-arabic">طريقة الدفع</TableHead>
                <TableHead className="text-right font-arabic">التاريخ</TableHead>
                <TableHead className="text-right font-arabic">الحالة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="font-arabic">{transaction.user}</TableCell>
                  <TableCell className="font-arabic">{transaction.unit}</TableCell>
                  <TableCell className="font-bold">{transaction.amount} ج.م</TableCell>
                  <TableCell className="text-green-600">{transaction.commission} ج.م</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span>{getPaymentMethodIcon(transaction.method)}</span>
                      <span className="capitalize">{transaction.method}</span>
                    </div>
                  </TableCell>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export { RevenueTracking };