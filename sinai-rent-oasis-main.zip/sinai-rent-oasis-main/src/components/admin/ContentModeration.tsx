import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, CheckCircle, X, Eye, MessageSquare, Home, Star } from "lucide-react";

const ContentModeration = () => {
  const [selectedTab, setSelectedTab] = useState("pending");

  const pendingReviews = [
    {
      id: 1,
      type: "unit",
      title: "شقة فاخرة في الزمالك",
      author: "محمد أحمد",
      submitted: "2024-01-20",
      reason: "محتوى جديد",
      status: "pending",
      content: "شقة 3 غرف في موقع متميز بالزمالك مع إطلالة على النيل..."
    },
    {
      id: 2,
      type: "review",
      title: "تقييم لوحدة سكنية",
      author: "سارة علي",
      submitted: "2024-01-19",
      reason: "بلاغ عن محتوى مسيء",
      status: "pending",
      content: "المكان سيء جداً ولا أنصح أحد بالسكن فيه..."
    },
    {
      id: 3,
      type: "comment",
      title: "تعليق على وحدة سكنية",
      author: "أحمد حسن",
      submitted: "2024-01-18",
      reason: "محتوى مشبوه",
      status: "pending",
      content: "هل يمكن التفاوض على السعر؟ لدي عرض أفضل..."
    }
  ];

  const reports = [
    {
      id: 1,
      reportedContent: "تقييم مسيء للمالك",
      reportedBy: "فاطمة محمد",
      reportedUser: "خالد أحمد",
      reason: "محتوى مسيء",
      date: "2024-01-20",
      status: "investigating"
    },
    {
      id: 2,
      reportedContent: "إعلان مضلل",
      reportedBy: "محمد علي",
      reportedUser: "سارة حسن",
      reason: "معلومات خاطئة",
      date: "2024-01-19",
      status: "resolved"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">قيد المراجعة</Badge>;
      case "approved":
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">موافق عليه</Badge>;
      case "rejected":
        return <Badge variant="destructive">مرفوض</Badge>;
      case "investigating":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">قيد التحقيق</Badge>;
      case "resolved":
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">تم الحل</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "unit":
        return <Home className="h-4 w-4" />;
      case "review":
        return <Star className="h-4 w-4" />;
      case "comment":
        return <MessageSquare className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "unit":
        return "وحدة سكنية";
      case "review":
        return "تقييم";
      case "comment":
        return "تعليق";
      default:
        return type;
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium font-arabic">
              قيد المراجعة
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingReviews.length}</div>
            <p className="text-xs text-muted-foreground font-arabic">
              عنصر بانتظار المراجعة
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium font-arabic">
              البلاغات
            </CardTitle>
            <MessageSquare className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reports.length}</div>
            <p className="text-xs text-muted-foreground font-arabic">
              بلاغ يحتاج متابعة
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium font-arabic">
              تم الموافقة عليه اليوم
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground font-arabic">
              عنصر تمت الموافقة عليه
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pending" className="font-arabic">المحتوى قيد المراجعة</TabsTrigger>
          <TabsTrigger value="reports" className="font-arabic">البلاغات</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-arabic">المحتوى قيد المراجعة</CardTitle>
              <CardDescription className="font-arabic">
                مراجعة المحتوى الجديد والمبلغ عنه
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right font-arabic">النوع</TableHead>
                    <TableHead className="text-right font-arabic">العنوان</TableHead>
                    <TableHead className="text-right font-arabic">المؤلف</TableHead>
                    <TableHead className="text-right font-arabic">السبب</TableHead>
                    <TableHead className="text-right font-arabic">التاريخ</TableHead>
                    <TableHead className="text-right font-arabic">الحالة</TableHead>
                    <TableHead className="text-right font-arabic">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingReviews.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getTypeIcon(item.type)}
                          <span className="font-arabic">{getTypeLabel(item.type)}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-arabic">{item.title}</TableCell>
                      <TableCell className="font-arabic">{item.author}</TableCell>
                      <TableCell className="font-arabic">{item.reason}</TableCell>
                      <TableCell>{item.submitted}</TableCell>
                      <TableCell>{getStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                                <Eye className="h-3 w-3" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle className="font-arabic">مراجعة المحتوى</DialogTitle>
                                <DialogDescription className="font-arabic">
                                  {item.title} - بواسطة {item.author}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <h4 className="font-bold font-arabic mb-2">المحتوى:</h4>
                                  <div className="p-3 bg-muted rounded-lg font-arabic">
                                    {item.content}
                                  </div>
                                </div>
                                <div>
                                  <h4 className="font-bold font-arabic mb-2">ملاحظات المراجعة:</h4>
                                  <Textarea placeholder="أضف ملاحظاتك هنا..." className="font-arabic" />
                                </div>
                                <div className="flex gap-2">
                                  <Button className="flex-1 font-arabic bg-green-600 hover:bg-green-700">
                                    <CheckCircle className="h-4 w-4 mr-2" />
                                    موافقة
                                  </Button>
                                  <Button variant="destructive" className="flex-1 font-arabic">
                                    <X className="h-4 w-4 mr-2" />
                                    رفض
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-green-600">
                            <CheckCircle className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-red-600">
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-arabic">البلاغات</CardTitle>
              <CardDescription className="font-arabic">
                متابعة البلاغات المقدمة من المستخدمين
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right font-arabic">المحتوى المبلغ عنه</TableHead>
                    <TableHead className="text-right font-arabic">المبلغ</TableHead>
                    <TableHead className="text-right font-arabic">المستخدم المبلغ عنه</TableHead>
                    <TableHead className="text-right font-arabic">السبب</TableHead>
                    <TableHead className="text-right font-arabic">التاريخ</TableHead>
                    <TableHead className="text-right font-arabic">الحالة</TableHead>
                    <TableHead className="text-right font-arabic">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell className="font-arabic">{report.reportedContent}</TableCell>
                      <TableCell className="font-arabic">{report.reportedBy}</TableCell>
                      <TableCell className="font-arabic">{report.reportedUser}</TableCell>
                      <TableCell className="font-arabic">{report.reason}</TableCell>
                      <TableCell>{report.date}</TableCell>
                      <TableCell>{getStatusBadge(report.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-green-600">
                            <CheckCircle className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export { ContentModeration };