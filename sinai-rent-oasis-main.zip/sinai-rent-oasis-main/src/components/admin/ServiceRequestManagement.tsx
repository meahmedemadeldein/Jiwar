import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Search, Settings, Clock, CheckCircle, AlertTriangle, User, MessageSquare, Calendar } from "lucide-react";

const ServiceRequestManagement = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");

  const serviceRequests = [
    {
      id: 1,
      user: "أحمد محمد",
      unit: "شقة في المعادي - الوحدة رقم 15",
      service: "صيانة السباكة",
      description: "تسريب في حنفية المطبخ يحتاج إصلاح عاجل",
      priority: "high",
      status: "pending",
      created: "2024-01-20",
      assignedTo: "",
      category: "maintenance"
    },
    {
      id: 2,
      user: "فاطمة حسن",
      unit: "استوديو في الزمالك - الوحدة رقم 8",
      service: "تنظيف دوري",
      description: "طلب تنظيف أسبوعي للوحدة",
      priority: "low",
      status: "in_progress",
      created: "2024-01-19",
      assignedTo: "محمد علي - فريق التنظيف",
      category: "cleaning"
    },
    {
      id: 3,
      user: "محمد إبراهيم",
      unit: "شقة في المهندسين - الوحدة رقم 22",
      service: "إصلاح التكييف",
      description: "التكييف لا يعمل بكفاءة ويحتاج فحص",
      priority: "medium",
      status: "completed",
      created: "2024-01-18",
      assignedTo: "خالد أحمد - فني التكييف",
      category: "maintenance"
    },
    {
      id: 4,
      user: "سارة أحمد",
      unit: "فيلا في التجمع الخامس - الوحدة رقم 3",
      service: "طلب إضافات",
      description: "إضافة شبكة واي فاي قوية للطابق الثاني",
      priority: "medium",
      status: "pending",
      created: "2024-01-17",
      assignedTo: "",
      category: "addition"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">قيد الانتظار</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">قيد التنفيذ</Badge>;
      case "completed":
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">مكتمل</Badge>;
      case "cancelled":
        return <Badge variant="destructive">ملغي</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive">عاجل</Badge>;
      case "medium":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">متوسط</Badge>;
      case "low":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">منخفض</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "maintenance":
        return "صيانة";
      case "cleaning":
        return "تنظيف";
      case "addition":
        return "إضافات";
      default:
        return category;
    }
  };

  const filteredRequests = serviceRequests.filter(request => {
    const matchesSearch = request.user.includes(searchQuery) || 
                         request.service.includes(searchQuery) || 
                         request.unit.includes(searchQuery);
    const matchesStatus = statusFilter === "all" || request.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || request.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const stats = [
    {
      title: "إجمالي الطلبات",
      value: serviceRequests.length.toString(),
      icon: Settings,
      color: "text-blue-600"
    },
    {
      title: "قيد الانتظار",
      value: serviceRequests.filter(r => r.status === "pending").length.toString(),
      icon: Clock,
      color: "text-yellow-600"
    },
    {
      title: "قيد التنفيذ",
      value: serviceRequests.filter(r => r.status === "in_progress").length.toString(),
      icon: AlertTriangle,
      color: "text-blue-600"
    },
    {
      title: "مكتمل",
      value: serviceRequests.filter(r => r.status === "completed").length.toString(),
      icon: CheckCircle,
      color: "text-green-600"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium font-arabic">
                  {stat.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-col sm:flex-row gap-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="البحث في طلبات الخدمة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 font-arabic"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="تصفية حسب الحالة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="pending">قيد الانتظار</SelectItem>
              <SelectItem value="in_progress">قيد التنفيذ</SelectItem>
              <SelectItem value="completed">مكتمل</SelectItem>
              <SelectItem value="cancelled">ملغي</SelectItem>
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="تصفية حسب الأولوية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الأولويات</SelectItem>
              <SelectItem value="high">عاجل</SelectItem>
              <SelectItem value="medium">متوسط</SelectItem>
              <SelectItem value="low">منخفض</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-arabic">طلبات الخدمة</CardTitle>
          <CardDescription className="font-arabic">
            إدارة ومتابعة جميع طلبات الخدمة ({filteredRequests.length} طلب)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right font-arabic">المستخدم</TableHead>
                  <TableHead className="text-right font-arabic">الوحدة</TableHead>
                  <TableHead className="text-right font-arabic">الخدمة</TableHead>
                  <TableHead className="text-right font-arabic">الفئة</TableHead>
                  <TableHead className="text-right font-arabic">الأولوية</TableHead>
                  <TableHead className="text-right font-arabic">الحالة</TableHead>
                  <TableHead className="text-right font-arabic">مُسند إلى</TableHead>
                  <TableHead className="text-right font-arabic">التاريخ</TableHead>
                  <TableHead className="text-right font-arabic">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-arabic">{request.user}</TableCell>
                    <TableCell className="font-arabic text-sm">{request.unit}</TableCell>
                    <TableCell className="font-arabic">{request.service}</TableCell>
                    <TableCell className="font-arabic">{getCategoryLabel(request.category)}</TableCell>
                    <TableCell>{getPriorityBadge(request.priority)}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    <TableCell className="font-arabic text-sm">
                      {request.assignedTo || "غير مُسند"}
                    </TableCell>
                    <TableCell>{request.created}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="h-8 px-2 font-arabic">
                              عرض
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle className="font-arabic">تفاصيل طلب الخدمة</DialogTitle>
                              <DialogDescription className="font-arabic">
                                طلب رقم #{request.id} - {request.service}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="font-bold font-arabic">المستخدم:</label>
                                  <p className="font-arabic">{request.user}</p>
                                </div>
                                <div>
                                  <label className="font-bold font-arabic">الوحدة:</label>
                                  <p className="font-arabic text-sm">{request.unit}</p>
                                </div>
                              </div>
                              <div>
                                <label className="font-bold font-arabic">وصف المشكلة:</label>
                                <p className="font-arabic p-3 bg-muted rounded-lg">{request.description}</p>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="font-bold font-arabic">الأولوية:</label>
                                  <div className="mt-1">{getPriorityBadge(request.priority)}</div>
                                </div>
                                <div>
                                  <label className="font-bold font-arabic">الحالة:</label>
                                  <div className="mt-1">{getStatusBadge(request.status)}</div>
                                </div>
                              </div>
                              <div>
                                <label className="font-bold font-arabic">ملاحظات إضافية:</label>
                                <Textarea placeholder="أضف ملاحظاتك..." className="font-arabic" />
                              </div>
                              <div className="flex gap-2">
                                <Button className="flex-1 font-arabic">تحديث الحالة</Button>
                                <Button variant="outline" className="flex-1 font-arabic">إسناد المهمة</Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button size="sm" variant="outline" className="h-8 px-2 font-arabic">
                          إسناد
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export { ServiceRequestManagement };