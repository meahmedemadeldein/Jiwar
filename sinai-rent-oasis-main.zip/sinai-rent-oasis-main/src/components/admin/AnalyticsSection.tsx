import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Users, Home, Eye, MessageSquare } from "lucide-react";

const AnalyticsSection = () => {
  const stats = [
    {
      title: "إجمالي المستخدمين",
      value: "2,456",
      change: "+12%",
      trend: "up",
      icon: Users,
      description: "من الشهر الماضي"
    },
    {
      title: "الوحدات النشطة",
      value: "89",
      change: "+5%",
      trend: "up",
      icon: Home,
      description: "وحدة متاحة للإيجار"
    },
    {
      title: "مشاهدات الصفحة",
      value: "15.2K",
      change: "-3%",
      trend: "down",
      icon: Eye,
      description: "في آخر 30 يوم"
    },
    {
      title: "طلبات الخدمة",
      value: "234",
      change: "+18%",
      trend: "up",
      icon: MessageSquare,
      description: "طلب جديد هذا الشهر"
    }
  ];

  const cityStats = [
    { city: "القاهرة", bookings: 45, revenue: "125,000", percentage: 85 },
    { city: "الإسكندرية", bookings: 32, revenue: "89,500", percentage: 70 },
    { city: "الغردقة", bookings: 28, revenue: "76,200", percentage: 60 },
    { city: "شرم الشيخ", bookings: 15, revenue: "41,800", percentage: 35 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown;
          
          return (
            <Card key={stat.title} className="relative overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium font-arabic">
                  {stat.title}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className={`flex items-center text-xs ${
                  stat.trend === "up" ? "text-green-600" : "text-red-600"
                }`}>
                  <TrendIcon className="h-3 w-3 mr-1" />
                  {stat.change}
                </div>
                <p className="text-xs text-muted-foreground font-arabic mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic">إحصائيات الحجوزات حسب المدينة</CardTitle>
            <CardDescription className="font-arabic">
              توزيع الحجوزات والإيرادات لكل مدينة
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {cityStats.map((city) => (
              <div key={city.city} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium font-arabic">{city.city}</span>
                  <div className="text-sm text-muted-foreground">
                    {city.bookings} حجز • {city.revenue} ج.م
                  </div>
                </div>
                <Progress value={city.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-arabic">معدل النمو الشهري</CardTitle>
            <CardDescription className="font-arabic">
              نمو المستخدمين والحجوزات في آخر 6 أشهر
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل النمو في المستخدمين</span>
                <span className="font-bold text-green-600">+15.3%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل النمو في الحجوزات</span>
                <span className="font-bold text-green-600">+22.7%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل النمو في الإيرادات</span>
                <span className="font-bold text-green-600">+18.9%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-arabic">معدل الرضا</span>
                <span className="font-bold text-blue-600">4.8/5</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export { AnalyticsSection };