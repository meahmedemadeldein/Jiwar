import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Search, UserPlus, Edit, Ban, CheckCircle, Clock, AlertTriangle } from "lucide-react";

const UserManagement = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const users = [
    {
      id: 1,
      name: "أحمد محمد علي",
      email: "ahmed@example.com",
      phone: "+20 100 123 4567",
      status: "active",
      role: "student",
      joinDate: "2024-01-15",
      bookings: 3,
      totalSpent: "4,500"
    },
    {
      id: 2,
      name: "فاطمة حسن أحمد",
      email: "fatma@example.com",
      phone: "+20 101 234 5678",
      status: "pending",
      role: "student",
      joinDate: "2024-02-20",
      bookings: 1,
      totalSpent: "1,200"
    },
    {
      id: 3,
      name: "محمد إبراهيم محمود",
      email: "mohamed@example.com",
      phone: "+20 102 345 6789",
      status: "suspended",
      role: "student",
      joinDate: "2023-11-10",
      bookings: 5,
      totalSpent: "8,900"
    },
    {
      id: 4,
      name: "سارة عبد الرحمن",
      email: "sara@example.com",
      phone: "+20 103 456 7890",
      status: "active",
      role: "owner",
      joinDate: "2023-08-05",
      bookings: 0,
      totalSpent: "0"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">نشط</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">قيد المراجعة</Badge>;
      case "suspended":
        return <Badge variant="destructive">معلق</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRoleLabel = (role: string) => {
    return role === "student" ? "طالب" : "مالك عقار";
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.includes(searchQuery) || user.email.includes(searchQuery);
    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-col sm:flex-row gap-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="البحث عن مستخدم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 font-arabic"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="تصفية حسب الحالة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="active">نشط</SelectItem>
              <SelectItem value="pending">قيد المراجعة</SelectItem>
              <SelectItem value="suspended">معلق</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="font-arabic">
              <UserPlus className="h-4 w-4 mr-2" />
              إضافة مستخدم جديد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-arabic">إضافة مستخدم جديد</DialogTitle>
              <DialogDescription className="font-arabic">
                قم بإدخال بيانات المستخدم الجديد
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Input placeholder="الاسم الكامل" className="font-arabic" />
              <Input placeholder="البريد الإلكتروني" type="email" />
              <Input placeholder="رقم الهاتف" />
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="نوع المستخدم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">طالب</SelectItem>
                  <SelectItem value="owner">مالك عقار</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button className="flex-1 font-arabic">إضافة المستخدم</Button>
                <Button variant="outline" className="flex-1 font-arabic">إلغاء</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-arabic">قائمة المستخدمين</CardTitle>
          <CardDescription className="font-arabic">
            إدارة جميع المستخدمين المسجلين في النظام ({filteredUsers.length} مستخدم)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right font-arabic">الاسم</TableHead>
                  <TableHead className="text-right font-arabic">البريد الإلكتروني</TableHead>
                  <TableHead className="text-right font-arabic">الهاتف</TableHead>
                  <TableHead className="text-right font-arabic">النوع</TableHead>
                  <TableHead className="text-right font-arabic">الحالة</TableHead>
                  <TableHead className="text-right font-arabic">الحجوزات</TableHead>
                  <TableHead className="text-right font-arabic">إجمالي الإنفاق</TableHead>
                  <TableHead className="text-right font-arabic">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium font-arabic">{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.phone}</TableCell>
                    <TableCell className="font-arabic">{getRoleLabel(user.role)}</TableCell>
                    <TableCell>{getStatusBadge(user.status)}</TableCell>
                    <TableCell>{user.bookings}</TableCell>
                    <TableCell className="font-arabic">{user.totalSpent} ج.م</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                          <Edit className="h-3 w-3" />
                        </Button>
                        {user.status === "active" ? (
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-red-600">
                            <Ban className="h-3 w-3" />
                          </Button>
                        ) : user.status === "suspended" ? (
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-green-600">
                            <CheckCircle className="h-3 w-3" />
                          </Button>
                        ) : (
                          <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-blue-600">
                            <Clock className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export { UserManagement };