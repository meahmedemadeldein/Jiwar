import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { Home, Building } from "lucide-react";

interface RentalRequestData {
  name: string;
  phone: string;
  email: string;
  city: string;
  budget: string;
  roomType: string;
  message: string;
}

interface ListingRequestData {
  ownerName: string;
  phone: string;
  email: string;
  propertyType: string;
  location: string;
  price: string;
  description: string;
}

export const RentalRequestForm = () => {
  const [activeForm, setActiveForm] = useState<"rent" | "list">("rent");
  const { toast } = useToast();

  const rentForm = useForm<RentalRequestData>();
  const listForm = useForm<ListingRequestData>();

  const onRentSubmit = (data: RentalRequestData) => {
    // Save to localStorage for now
    const rentRequests = JSON.parse(localStorage.getItem('rent-requests') || '[]');
    rentRequests.push({
      id: Date.now(),
      ...data,
      type: 'rent',
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('rent-requests', JSON.stringify(rentRequests));
    
    toast({
      title: "تم إرسال طلب الإيجار",
      description: "سنتواصل معك قريباً",
    });
    
    rentForm.reset();
  };

  const onListSubmit = (data: ListingRequestData) => {
    // Save to localStorage for now
    const listRequests = JSON.parse(localStorage.getItem('list-requests') || '[]');
    listRequests.push({
      id: Date.now(),
      ...data,
      type: 'list',
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('list-requests', JSON.stringify(listRequests));
    
    toast({
      title: "تم إرسال طلب إدراج العقار",
      description: "سنتواصل معك قريباً لمراجعة العقار",
    });
    
    listForm.reset();
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Form Toggle */}
      <div className="flex gap-2 justify-center">
        <Button
          variant={activeForm === "rent" ? "default" : "outline"}
          onClick={() => setActiveForm("rent")}
          className="font-arabic flex items-center gap-2"
        >
          <Home className="h-4 w-4" />
          طلب إيجار وحدة
        </Button>
        <Button
          variant={activeForm === "list" ? "default" : "outline"}
          onClick={() => setActiveForm("list")}
          className="font-arabic flex items-center gap-2"
        >
          <Building className="h-4 w-4" />
          إدراج وحدة للإيجار
        </Button>
      </div>

      {/* Rent Request Form */}
      {activeForm === "rent" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">طلب إيجار وحدة سكنية</CardTitle>
            <CardDescription className="font-arabic text-right">
              املأ البيانات التالية وسنتواصل معك لإيجاد الوحدة المناسبة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...rentForm}>
              <form onSubmit={rentForm.handleSubmit(onRentSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={rentForm.control}
                    name="name"
                    rules={{ required: "الاسم مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">الاسم الكامل</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="أدخل اسمك الكامل" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={rentForm.control}
                    name="phone"
                    rules={{ required: "رقم الهاتف مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">رقم الهاتف</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="05xxxxxxxx" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={rentForm.control}
                  name="email"
                  rules={{ required: "البريد الإلكتروني مطلوب" }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">البريد الإلكتروني</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" className="text-right font-arabic" placeholder="example@email.com" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={rentForm.control}
                    name="city"
                    rules={{ required: "المدينة مطلوبة" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">المدينة المفضلة</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="font-arabic">
                              <SelectValue placeholder="اختر المدينة" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="cairo">القاهرة</SelectItem>
                            <SelectItem value="alexandria">الإسكندرية</SelectItem>
                            <SelectItem value="sharm">شرم الشيخ</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={rentForm.control}
                    name="budget"
                    rules={{ required: "الميزانية مطلوبة" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">الميزانية الشهرية</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="مثال: 5000 جنيه" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={rentForm.control}
                  name="roomType"
                  rules={{ required: "نوع الوحدة مطلوب" }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">نوع الوحدة المطلوبة</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="font-arabic">
                            <SelectValue placeholder="اختر نوع الوحدة" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="studio">استوديو</SelectItem>
                          <SelectItem value="1bed">غرفة نوم واحدة</SelectItem>
                          <SelectItem value="2bed">غرفتين نوم</SelectItem>
                          <SelectItem value="3bed">ثلاث غرف نوم</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={rentForm.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">ملاحظات إضافية</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          className="text-right font-arabic" 
                          placeholder="أي متطلبات أو ملاحظات خاصة..."
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full font-arabic">
                  إرسال طلب الإيجار
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      {/* List Request Form */}
      {activeForm === "list" && (
        <Card>
          <CardHeader>
            <CardTitle className="font-arabic text-right">إدراج وحدة سكنية للإيجار</CardTitle>
            <CardDescription className="font-arabic text-right">
              أدرج وحدتك السكنية على منصتنا واحصل على أفضل المستأجرين
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...listForm}>
              <form onSubmit={listForm.handleSubmit(onListSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={listForm.control}
                    name="ownerName"
                    rules={{ required: "اسم المالك مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">اسم مالك العقار</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="أدخل اسمك الكامل" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={listForm.control}
                    name="phone"
                    rules={{ required: "رقم الهاتف مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">رقم الهاتف</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="05xxxxxxxx" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={listForm.control}
                  name="email"
                  rules={{ required: "البريد الإلكتروني مطلوب" }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">البريد الإلكتروني</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" className="text-right font-arabic" placeholder="example@email.com" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={listForm.control}
                    name="propertyType"
                    rules={{ required: "نوع العقار مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">نوع العقار</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="font-arabic">
                              <SelectValue placeholder="اختر نوع العقار" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="apartment">شقة سكنية</SelectItem>
                            <SelectItem value="villa">فيلا</SelectItem>
                            <SelectItem value="studio">استوديو</SelectItem>
                            <SelectItem value="duplex">دوبلكس</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={listForm.control}
                    name="location"
                    rules={{ required: "الموقع مطلوب" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-arabic">موقع العقار</FormLabel>
                        <FormControl>
                          <Input {...field} className="text-right font-arabic" placeholder="المدينة والحي" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={listForm.control}
                  name="price"
                  rules={{ required: "السعر مطلوب" }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">السعر الشهري المطلوب</FormLabel>
                      <FormControl>
                        <Input {...field} className="text-right font-arabic" placeholder="مثال: 8000 جنيه شهرياً" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={listForm.control}
                  name="description"
                  rules={{ required: "وصف العقار مطلوب" }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-arabic">وصف العقار</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          className="text-right font-arabic" 
                          placeholder="اكتب وصفاً مفصلاً للعقار، المساحة، المرافق، إلخ..."
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full font-arabic">
                  إرسال طلب الإدراج
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
};