import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Users, Bed, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface UnitCardProps {
  id: string;
  title: string;
  city: string;
  price: number;
  image: string;
  type: string;
  capacity: number;
  available: boolean;
}

export const UnitCard = ({ id, title, city, price, image, type, capacity, available }: UnitCardProps) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    navigate(`/unit/${id}`);
  };

  return (
    <Card className="overflow-hidden hover:shadow-warm transition-smooth cursor-pointer group">
      <div className="relative">
        <img 
          src={image} 
          alt={title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-smooth"
        />
        <div className="absolute top-3 right-3">
          <Badge variant={available ? "default" : "secondary"} className="font-arabic">
            {available ? "متاح" : "محجوز"}
          </Badge>
        </div>
        <div className="absolute bottom-3 left-3">
          <Badge variant="outline" className="bg-white/90 font-arabic">
            {type}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-4 space-y-3">
        <div className="text-right">
          <h3 className="font-semibold text-lg font-arabic">{title}</h3>
          <div className="flex items-center gap-1 justify-end text-muted-foreground">
            <span className="text-sm font-arabic">{city}</span>
            <MapPin className="h-4 w-4" />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-muted-foreground">
              <span className="text-sm font-arabic">{capacity}</span>
              <Users className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <span className="text-sm font-arabic">غرفة</span>
              <Bed className="h-4 w-4" />
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-xl font-bold text-sinai-blue font-arabic">
              {price} جنيه
            </div>
            <div className="text-xs text-muted-foreground font-arabic">شهرياً</div>
          </div>
        </div>

        <Button 
          className="w-full font-arabic" 
          onClick={handleViewDetails}
          disabled={!available}
        >
          <Eye className="h-4 w-4 ml-2" />
          عرض التفاصيل
        </Button>
      </CardContent>
    </Card>
  );
};