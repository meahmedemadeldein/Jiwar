import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";

interface CityFilterProps {
  selectedCity: string;
  onCityChange: (city: string) => void;
}

const cities = [
  { id: "all", name: "جميع المدن", count: 200 },
  { id: "sharm", name: "شرم الشيخ", count: 120 },
  { id: "ras-sadr", name: "رأس سدر", count: 45 },
  { id: "el-tur", name: "الطور", count: 35 },
];

export const CityFilter = ({ selectedCity, onCityChange }: CityFilterProps) => {
  return (
    <div className="bg-white rounded-xl shadow-elegant border p-6 mb-8">
      <h2 className="text-xl font-bold font-arabic mb-4 text-right">اختر المدينة</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cities.map((city) => (
          <Button
            key={city.id}
            variant={selectedCity === city.id ? "default" : "outline"}
            className="h-auto p-4 flex-col gap-2 font-arabic transition-smooth"
            onClick={() => onCityChange(city.id)}
          >
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              <span className="font-semibold">{city.name}</span>
            </div>
            <span className="text-sm opacity-75">{city.count} وحدة</span>
          </Button>
        ))}
      </div>
    </div>
  );
};