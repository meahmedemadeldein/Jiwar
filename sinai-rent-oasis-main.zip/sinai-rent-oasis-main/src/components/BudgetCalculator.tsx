import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calculator, PiggyBank, AlertTriangle, CheckCircle, TrendingUp } from "lucide-react";
import { Slider } from "@/components/ui/slider";

interface BudgetCalculatorProps {
  unitPrice?: number;
  className?: string;
}

export const BudgetCalculator = ({ unitPrice = 0, className }: BudgetCalculatorProps) => {
  const [monthlyIncome, setMonthlyIncome] = useState(0);
  const [familySupport, setFamilySupport] = useState(0);
  const [scholarships, setScholarships] = useState(0);
  const [partTimeIncome, setPartTimeIncome] = useState(0);
  const [otherExpenses, setOtherExpenses] = useState(1500);
  const [savingsGoal, setSavingsGoal] = useState([10]);

  const totalIncome = monthlyIncome + familySupport + scholarships + partTimeIncome;
  const rentBudget = unitPrice || 0;
  const estimatedUtilities = rentBudget * 0.15; // 15% of rent for utilities
  const foodExpenses = 800; // Estimated food cost for students
  const transportExpenses = 300; // Estimated transport cost
  const totalExpenses = rentBudget + estimatedUtilities + foodExpenses + transportExpenses + otherExpenses;
  const savingsAmount = totalIncome * (savingsGoal[0] / 100);
  const remainingBudget = totalIncome - totalExpenses - savingsAmount;

  const getBudgetStatus = () => {
    if (remainingBudget >= 500) return { status: "excellent", color: "text-green-600", icon: CheckCircle };
    if (remainingBudget >= 0) return { status: "good", color: "text-blue-600", icon: TrendingUp };
    if (remainingBudget >= -500) return { status: "tight", color: "text-yellow-600", icon: AlertTriangle };
    return { status: "difficult", color: "text-red-600", icon: AlertTriangle };
  };

  const budgetStatus = getBudgetStatus();
  const StatusIcon = budgetStatus.icon;

  const getRecommendations = () => {
    const recommendations = [];
    
    if (remainingBudget < 0) {
      recommendations.push("فكر في البحث عن وحدة أرخص أو سكن مشترك");
      recommendations.push("ابحث عن مصادر دخل إضافية مثل العمل الجزئي");
    }
    
    if (rentBudget > totalIncome * 0.4) {
      recommendations.push("الإيجار يتجاوز 40% من دخلك - حاول إيجاد خيار أرخص");
    }
    
    if (savingsGoal[0] < 10) {
      recommendations.push("حاول توفير 10% على الأقل من دخلك للطوارئ");
    }
    
    if (otherExpenses > totalIncome * 0.3) {
      recommendations.push("المصروفات الأخرى مرتفعة - راجع إنفاقك");
    }

    if (recommendations.length === 0) {
      recommendations.push("ميزانيتك متوازنة بشكل جيد!");
      recommendations.push("فكر في زيادة المدخرات إذا أمكن");
    }
    
    return recommendations;
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-arabic text-right">
          <Calculator className="h-5 w-5" />
          حاسبة الميزانية الطلابية
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Income Section */}
        <div>
          <h3 className="font-semibold font-arabic mb-4 text-right">مصادر الدخل الشهري</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="monthly-income" className="font-arabic">الدخل الأساسي (جنيه)</Label>
              <Input
                id="monthly-income"
                type="number"
                value={monthlyIncome || ""}
                onChange={(e) => setMonthlyIncome(Number(e.target.value) || 0)}
                placeholder="مثل: 3000"
                className="font-arabic text-right"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="family-support" className="font-arabic">دعم الأسرة (جنيه)</Label>
              <Input
                id="family-support"
                type="number"
                value={familySupport || ""}
                onChange={(e) => setFamilySupport(Number(e.target.value) || 0)}
                placeholder="مثل: 2000"
                className="font-arabic text-right"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="scholarships" className="font-arabic">المنح الدراسية (جنيه)</Label>
              <Input
                id="scholarships"
                type="number"
                value={scholarships || ""}
                onChange={(e) => setScholarships(Number(e.target.value) || 0)}
                placeholder="مثل: 1000"
                className="font-arabic text-right"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="parttime-income" className="font-arabic">العمل الجزئي (جنيه)</Label>
              <Input
                id="parttime-income"
                type="number"
                value={partTimeIncome || ""}
                onChange={(e) => setPartTimeIncome(Number(e.target.value) || 0)}
                placeholder="مثل: 1500"
                className="font-arabic text-right"
              />
            </div>
          </div>
        </div>

        {/* Expenses Section */}
        <div>
          <h3 className="font-semibold font-arabic mb-4 text-right">المصروفات الشهرية</h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex justify-between p-3 bg-muted rounded-lg">
                <span className="font-arabic">{rentBudget} جنيه</span>
                <span className="font-arabic">الإيجار</span>
              </div>
              <div className="flex justify-between p-3 bg-muted rounded-lg">
                <span className="font-arabic">{Math.round(estimatedUtilities)} جنيه</span>
                <span className="font-arabic">المرافق (مقدر)</span>
              </div>
              <div className="flex justify-between p-3 bg-muted rounded-lg">
                <span className="font-arabic">{foodExpenses} جنيه</span>
                <span className="font-arabic">الطعام (مقدر)</span>
              </div>
              <div className="flex justify-between p-3 bg-muted rounded-lg">
                <span className="font-arabic">{transportExpenses} جنيه</span>
                <span className="font-arabic">المواصلات (مقدر)</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="other-expenses" className="font-arabic">مصروفات أخرى (جنيه)</Label>
              <Input
                id="other-expenses"
                type="number"
                value={otherExpenses || ""}
                onChange={(e) => setOtherExpenses(Number(e.target.value) || 0)}
                placeholder="مثل: 1500"
                className="font-arabic text-right"
              />
            </div>
          </div>
        </div>

        {/* Savings Goal */}
        <div>
          <Label className="font-arabic mb-3 block">هدف التوفير (% من الدخل)</Label>
          <div className="px-3">
            <Slider
              value={savingsGoal}
              onValueChange={setSavingsGoal}
              max={30}
              min={0}
              step={5}
              className="mb-2"
            />
            <div className="flex justify-between text-sm text-muted-foreground font-arabic">
              <span>30%</span>
              <span className="font-bold">{savingsGoal[0]}% ({Math.round(savingsAmount)} جنيه)</span>
              <span>0%</span>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="border-t pt-6">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 font-arabic">{totalIncome}</div>
              <div className="text-sm text-muted-foreground font-arabic">إجمالي الدخل</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600 font-arabic">{Math.round(totalExpenses)}</div>
              <div className="text-sm text-muted-foreground font-arabic">إجمالي المصروفات</div>
            </div>
          </div>
          
          <div className={`text-center p-4 rounded-lg ${remainingBudget >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
            <div className={`flex items-center justify-center gap-2 mb-2 ${budgetStatus.color}`}>
              <StatusIcon className="h-5 w-5" />
              <span className="text-2xl font-bold font-arabic">
                {remainingBudget >= 0 ? '+' : ''}{Math.round(remainingBudget)}
              </span>
              <span className="font-arabic">جنيه</span>
            </div>
            <div className="text-sm text-muted-foreground font-arabic">
              {remainingBudget >= 0 ? 'فائض شهري' : 'عجز شهري'}
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div>
          <h3 className="font-semibold font-arabic mb-3 text-right flex items-center gap-2">
            <PiggyBank className="h-4 w-4" />
            نصائح مالية
          </h3>
          <div className="space-y-2">
            {getRecommendations().map((recommendation, index) => (
              <div key={index} className="flex items-start gap-2 text-sm p-3 bg-muted rounded-lg">
                <Badge variant="secondary" className="mt-0.5">{index + 1}</Badge>
                <span className="font-arabic text-right flex-1">{recommendation}</span>
              </div>
            ))}
          </div>
        </div>

      </CardContent>
    </Card>
  );
};