import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, Calendar } from "lucide-react";
import heroImage from "@/assets/hero-image.jpg";

export const Hero = () => {
  return (
    <section className="relative min-h-[70vh] flex items-center bg-gradient-to-br from-background to-muted">
      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Content */}
          <div className="text-right space-y-6">
            <Badge variant="secondary" className="font-arabic">
              <MapPin className="h-4 w-4 ml-2" />
              جنوب سيناء، مصر
            </Badge>
            
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground font-arabic leading-tight">
              اعثر على سكنك المثالي في 
              <span className="text-sinai-blue"> سيناء</span>
            </h1>
            
            <p className="text-lg text-muted-foreground font-arabic max-w-lg">
              منصة إيجار وحدات سكنية مصممة خصيصاً للطلاب الجامعيين في شرم الشيخ، رأس سدر، والطور. 
              اكتشف خيارات سكنية مريحة وآمنة بأسعار مناسبة.
            </p>

            <div className="flex flex-wrap gap-4 justify-end">
              <div className="flex items-center gap-2 text-muted-foreground font-arabic">
                <Users className="h-5 w-5" />
                <span>للطلاب الجامعيين</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground font-arabic">
                <Calendar className="h-5 w-5" />
                <span>إيجار مرن</span>
              </div>
            </div>

            <div className="flex gap-4 justify-end">
              <Button variant="hero" size="lg" className="font-arabic">
                استكشف الوحدات
              </Button>
              <Button variant="outline" size="lg" className="font-arabic">
                كيف يعمل الموقع؟
              </Button>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-warm">
              <img 
                src={heroImage} 
                alt="وحدة سكنية في شرم الشيخ" 
                className="w-full h-[500px] object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-4 shadow-elegant border">
              <div className="text-center font-arabic">
                <div className="text-2xl font-bold text-sinai-blue">200+</div>
                <div className="text-sm text-muted-foreground">وحدة متاحة</div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};