import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, Users, Wrench, Building } from "lucide-react";
import { units } from "@/data/units";

export const StatsSection = () => {
  const [stats, setStats] = useState({
    totalUnits: 0,
    rentRequests: 0,
    listRequests: 0,
    serviceRequests: 0
  });

  useEffect(() => {
    // Get counts from localStorage and static data
    const rentRequests = JSON.parse(localStorage.getItem('rent-requests') || '[]');
    const listRequests = JSON.parse(localStorage.getItem('list-requests') || '[]');
    const serviceRequests = JSON.parse(localStorage.getItem('service-requests') || '[]');

    setStats({
      totalUnits: units.length,
      rentRequests: rentRequests.length,
      listRequests: listRequests.length,
      serviceRequests: serviceRequests.length
    });
  }, []);

  const statsData = [
    {
      title: "الوحدات المتاحة",
      value: stats.totalUnits,
      icon: Home,
      description: "وحدة سكنية متاحة للإيجار",
      color: "text-primary"
    },
    {
      title: "طلبات الإيجار",
      value: stats.rentRequests,
      icon: Users,
      description: "طلب بحث عن سكن",
      color: "text-green-600"
    },
    {
      title: "طلبات الإدراج",
      value: stats.listRequests,
      icon: Building,
      description: "طلب إدراج عقار",
      color: "text-blue-600"
    },
    {
      title: "طلبات الخدمة",
      value: stats.serviceRequests,
      icon: Wrench,
      description: "طلب صيانة وخدمة",
      color: "text-orange-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => {
        const IconComponent = stat.icon;
        return (
          <Card key={index} className="text-center">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-center mb-2">
                <IconComponent className={`h-8 w-8 ${stat.color}`} />
              </div>
              <CardTitle className="font-arabic text-lg">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${stat.color} mb-1`}>
                {stat.value}
              </div>
              <p className="text-sm text-muted-foreground font-arabic">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};