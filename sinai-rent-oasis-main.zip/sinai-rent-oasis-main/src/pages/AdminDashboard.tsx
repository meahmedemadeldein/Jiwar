import { useState } from "react";
import { Header } from "@/components/Header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AnalyticsSection } from "@/components/admin/AnalyticsSection";
import { UserManagement } from "@/components/admin/UserManagement";
import { ContentModeration } from "@/components/admin/ContentModeration";
import { RevenueTracking } from "@/components/admin/RevenueTracking";
import { ServiceRequestManagement } from "@/components/admin/ServiceRequestManagement";
import { Shield, BarChart3, Users, FileText, DollarSign, Settings } from "lucide-react";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("analytics");

  const tabs = [
    { id: "analytics", label: "التحليلات والتقارير", icon: BarChart3, component: AnalyticsSection },
    { id: "users", label: "إدارة المستخدمين", icon: Users, component: UserManagement },
    { id: "content", label: "مراقبة المحتوى", icon: FileText, component: ContentModeration },
    { id: "revenue", label: "تتبع الإيرادات", icon: DollarSign, component: RevenueTracking },
    { id: "services", label: "إدارة طلبات الخدمة", icon: Settings, component: ServiceRequestManagement },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold font-arabic">لوحة تحكم الإدارة</h1>
            <p className="text-muted-foreground font-arabic">إدارة ومراقبة النظام</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="flex items-center gap-2 font-arabic"
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {tabs.map((tab) => {
            const Component = tab.component;
            return (
              <TabsContent key={tab.id} value={tab.id} className="space-y-6">
                <Component />
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;