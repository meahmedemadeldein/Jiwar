import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, MapPin, Users, Phone, Check, Heart } from "lucide-react";
import { units } from "@/data/units";
import { useToast } from "@/hooks/use-toast";
import { BudgetCalculator } from "@/components/BudgetCalculator";
import { StudentFeatures } from "@/components/StudentFeatures";
import { AccessibilityFeatures } from "@/components/AccessibilityFeatures";

export default function UnitDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const unit = units.find(u => u.id === id);

  if (!unit) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center font-arabic">
          <h1 className="text-2xl font-bold mb-4">الوحدة غير موجودة</h1>
          <Button onClick={() => navigate("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  const handleRentRequest = () => {
    toast({
      title: "تم إرسال طلب الإيجار!",
      description: "سيتم التواصل معك خلال 24 ساعة لإتمام الإجراءات.",
    });
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/")}
            className="font-arabic"
          >
            <ArrowRight className="h-4 w-4 ml-2" />
            العودة للوحدات
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Image */}
            <div className="rounded-xl overflow-hidden shadow-elegant">
              <img 
                src={unit.image} 
                alt={unit.title}
                className="w-full h-96 object-cover"
              />
            </div>

            {/* Basic Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex gap-2">
                    <Badge variant={unit.available ? "default" : "secondary"} className="font-arabic">
                      {unit.available ? "متاح للإيجار" : "محجوز"}
                    </Badge>
                    <Badge variant="outline" className="font-arabic">
                      {unit.type}
                    </Badge>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>

                <h1 className="text-3xl font-bold font-arabic mb-2 text-right">{unit.title}</h1>
                
                <div className="flex items-center gap-2 justify-end text-muted-foreground mb-4">
                  <span className="font-arabic">{unit.location}</span>
                  <MapPin className="h-4 w-4" />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <span className="font-arabic">يتسع لـ {unit.capacity} طلاب</span>
                    <Users className="h-4 w-4" />
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-sinai-blue font-arabic">
                      {unit.price} جنيه
                    </div>
                    <div className="text-sm text-muted-foreground font-arabic">شهرياً</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold font-arabic mb-4 text-right">وصف الوحدة</h2>
                <p className="text-muted-foreground font-arabic text-right leading-relaxed">
                  {unit.description}
                </p>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold font-arabic mb-4 text-right">المرافق والخدمات</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {unit.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 justify-end">
                      <span className="text-sm font-arabic">{feature}</span>
                      <Check className="h-4 w-4 text-green-600" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Student-Specific Features */}
            <StudentFeatures unit={unit} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Booking Card */}
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="text-2xl font-bold text-sinai-blue font-arabic mb-1">
                    {unit.price} جنيه
                  </div>
                  <div className="text-sm text-muted-foreground font-arabic">شهرياً</div>
                </div>

                <div className="space-y-4">
                  <Button 
                    className="w-full font-arabic" 
                    size="lg"
                    disabled={!unit.available}
                    onClick={handleRentRequest}
                  >
                    {unit.available ? "طلب إيجار الوحدة" : "غير متاح حالياً"}
                  </Button>
                  
                  <Button variant="outline" className="w-full font-arabic">
                    <Phone className="h-4 w-4 ml-2" />
                    اتصل بالمالك
                  </Button>
                </div>

                <div className="mt-6 pt-6 border-t">
                  <h3 className="font-semibold font-arabic mb-2 text-right">معلومات التواصل</h3>
                  <div className="text-sm text-muted-foreground font-arabic text-right">
                    <div>الموقع: {unit.location}</div>
                    <div>الهاتف: {unit.contact}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Budget Calculator */}
            <BudgetCalculator unitPrice={unit.price} className="mb-6" />

            {/* Quick Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold font-arabic mb-4 text-right">معلومات سريعة</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">نوع الوحدة</span>
                    <span className="font-arabic">{unit.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">السعة</span>
                    <span className="font-arabic">{unit.capacity} طلاب</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المدينة</span>
                    <span className="font-arabic">{unit.city}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الحالة</span>
                    <span className="font-arabic">{unit.available ? "متاح" : "محجوز"}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Accessibility Features */}
      <AccessibilityFeatures />
    </div>
  );
}