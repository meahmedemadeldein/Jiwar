import { Header } from "@/components/Header";
import { RentalRequestForm } from "@/components/RentalRequestForm";
import { ServiceRequestForm } from "@/components/ServiceRequestForm";
import { StatsSection } from "@/components/StatsSection";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Home, Wrench } from "lucide-react";

const ServicesPage = () => {
  const [activeSection, setActiveSection] = useState<"rental" | "service">("rental");

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold font-arabic mb-4">
            خدماتنا
          </h1>
          <p className="text-xl text-muted-foreground font-arabic max-w-2xl mx-auto">
            نقدم لك أفضل الخدمات السكنية من إيجار الوحدات إلى خدمات الصيانة المتخصصة
          </p>
        </div>

        {/* Stats Section */}
        <StatsSection />

        {/* Service Toggle */}
        <div className="flex gap-4 justify-center mb-8">
          <Button
            size="lg"
            variant={activeSection === "rental" ? "default" : "outline"}
            onClick={() => setActiveSection("rental")}
            className="font-arabic flex items-center gap-2"
          >
            <Home className="h-5 w-5" />
            خدمات الإيجار
          </Button>
          <Button
            size="lg"
            variant={activeSection === "service" ? "default" : "outline"}
            onClick={() => setActiveSection("service")}
            className="font-arabic flex items-center gap-2"
          >
            <Wrench className="h-5 w-5" />
            خدمات الصيانة
          </Button>
        </div>

        {/* Active Section */}
        <div className="max-w-4xl mx-auto">
          {activeSection === "rental" ? (
            <RentalRequestForm />
          ) : (
            <ServiceRequestForm />
          )}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;