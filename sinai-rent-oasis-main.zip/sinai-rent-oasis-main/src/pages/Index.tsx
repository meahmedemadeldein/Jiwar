import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { CityFilter } from "@/components/CityFilter";
import { UnitCard } from "@/components/UnitCard";
import { SearchFilters } from "@/components/SearchFilters";
import { BudgetCalculator } from "@/components/BudgetCalculator";
import { AccessibilityFeatures } from "@/components/AccessibilityFeatures";
import { StatsSection } from "@/components/StatsSection";
import { units } from "@/data/units";

const Index = () => {
  const [selectedCity, setSelectedCity] = useState("all");
  const [filteredUnits, setFilteredUnits] = useState(units);
  const [showBudgetCalculator, setShowBudgetCalculator] = useState(false);

  const cityFilteredUnits = selectedCity === "all" 
    ? units 
    : units.filter(unit => unit.cityId === selectedCity);

  // Handle city filter changes
  const handleCityChange = (city: string) => {
    setSelectedCity(city);
    const newCityFiltered = city === "all" ? units : units.filter(unit => unit.cityId === city);
    setFilteredUnits(newCityFiltered);
  };

  const handleSaveSearch = (filters: any) => {
    // Save search to localStorage or backend
    const savedSearches = JSON.parse(localStorage.getItem('saved-searches') || '[]');
    savedSearches.push({
      id: Date.now(),
      name: `بحث ${new Date().toLocaleDateString('ar')}`,
      filters,
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('saved-searches', JSON.stringify(savedSearches));
    
    // Show success message
    console.log('تم حفظ البحث بنجاح');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      
      <section className="container mx-auto px-4 py-12">
        {/* Stats Section */}
        <StatsSection />
        
        <CityFilter selectedCity={selectedCity} onCityChange={handleCityChange} />
        
        {/* Enhanced Search and Filters */}
        <SearchFilters 
          units={cityFilteredUnits}
          onFilteredUnits={setFilteredUnits}
          onSaveSearch={handleSaveSearch}
        />

        {/* Budget Calculator Toggle */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex gap-2">
            <Button
              variant={showBudgetCalculator ? "default" : "outline"}
              onClick={() => setShowBudgetCalculator(!showBudgetCalculator)}
              className="font-arabic"
            >
              {showBudgetCalculator ? "إخفاء" : "إظهار"} حاسبة الميزانية
            </Button>
          </div>
          <div className="text-right">
            <h2 className="text-2xl font-bold font-arabic mb-2">
              الوحدات المتاحة
              {selectedCity !== "all" && (
                <span className="text-sinai-blue mr-2">
                  في {units.find(u => u.cityId === selectedCity)?.city}
                </span>
              )}
            </h2>
            <p className="text-muted-foreground font-arabic">
              {filteredUnits.length} وحدة متاحة
            </p>
          </div>
        </div>

        {/* Budget Calculator */}
        {showBudgetCalculator && (
          <div className="mb-8">
            <BudgetCalculator className="w-full" />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUnits.map((unit) => (
            <UnitCard key={unit.id} {...unit} />
          ))}
        </div>

        {filteredUnits.length === 0 && (
          <div className="text-center py-12">
            <div className="text-muted-foreground font-arabic">
              لا توجد وحدات متاحة في هذه المدينة حالياً
            </div>
          </div>
        )}
      </section>

      {/* Accessibility Features */}
      <AccessibilityFeatures />
    </div>
  );
};

export default Index;
